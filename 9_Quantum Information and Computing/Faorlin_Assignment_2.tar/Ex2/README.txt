-> WEEK 2 - Faorlin Tommaso (2021857) <- 

Exercise 1 (error_handling.f90)
included in Exercise 2 and Exercise 3

Exercise 2 (w2_ex2.f90)
compile with gfortran -W w2_ex2.f90 my_mat_mul.f90 error_handling.f90 -o w2_ex2.out
run with w2_ex2.out or w2_ex2.out -debug for debug mode

Exercise 3 (w2_ex3.f90)
compile with gfortran -W w2_ex3.f90 dc_matrix.f90 error_handling.f90 -o w2_ex3.out
run with w2_ex3.out or w2_ex3.out -debug for debug mode