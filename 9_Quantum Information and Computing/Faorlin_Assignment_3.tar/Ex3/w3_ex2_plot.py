import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from scipy.optimize import curve_fit

def func(s, alpha, beta, a, b):    
    return (a*np.power(s,alpha)*np.exp(-b*np.power(s,beta)))

x = []
file_in = open('data/herm_eigenvalues_spacing_norm.dat', 'r')
for y in file_in.read().split('\n'):
    x.append(float(y))

z = []
file_in = open('data/diag_eigenvalues_spacing_norm.dat', 'r')
for y in file_in.read().split('\n'):
    z.append(float(y))

print(max(x))

plt.xlim(0,5)

counts_x,bin_edges_x = np.histogram(x,100, density=True)
counts_z,bin_edges_z = np.histogram(z,100, density=True)

bin_centres_x = (bin_edges_x[:-1] + bin_edges_x[1:])/2.
bin_centres_z = (bin_edges_z[:-1] + bin_edges_z[1:])/2.

popt_x, pcov_x = curve_fit(func, bin_centres_x, counts_x)
popt_z, pcov_z = curve_fit(func, bin_centres_z, counts_z)

plt.hist(x, 100, density=True)
plt.hist(z, 100, density=True)
print(popt_x)
print(pcov_x)
print(popt_z)

plt.plot(bin_centres_x, func(bin_centres_x, popt_x[0], popt_x[1], popt_x[2], popt_x[3]))
plt.plot(bin_centres_z, func(bin_centres_z, popt_z[0], popt_z[1], popt_z[2], popt_z[3]))


plt.show()